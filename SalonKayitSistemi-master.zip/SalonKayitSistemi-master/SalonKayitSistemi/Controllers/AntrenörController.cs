﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SalonKayitSistemi;

namespace SalonKayitSistemi.Controllers
{
    public class AntrenörController : Controller
    {
        private SalonKayit1Entities db = new SalonKayit1Entities();

        // GET: Antrenör
        public ActionResult Index()
        {
            var antrenör = db.Antrenör.Include(a => a.SporDali);
            return View(antrenör.ToList());
        }

        // GET: Antrenör/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Antrenör antrenör = db.Antrenör.Find(id);
            if (antrenör == null)
            {
                return HttpNotFound();
            }
            return View(antrenör);
        }

        // GET: Antrenör/Create
        public ActionResult Create()
        {
            ViewBag.Antrenör_id = new SelectList(db.SporDali, "sporDali_id", "spor_secimi");
            return View();
        }

        // POST: Antrenör/Create
        // Aşırı gönderim saldırılarından korunmak için, bağlamak istediğiniz belirli özellikleri etkinleştirin, 
        // daha fazla bilgi için bkz. https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Antrenör_id,Antrenör_Bilgisi")] Antrenör antrenör)
        {
            if (ModelState.IsValid)
            {
                db.Antrenör.Add(antrenör);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Antrenör_id = new SelectList(db.SporDali, "sporDali_id", "spor_secimi", antrenör.Antrenör_id);
            return View(antrenör);
        }

        // GET: Antrenör/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Antrenör antrenör = db.Antrenör.Find(id);
            if (antrenör == null)
            {
                return HttpNotFound();
            }
            ViewBag.Antrenör_id = new SelectList(db.SporDali, "sporDali_id", "spor_secimi", antrenör.Antrenör_id);
            return View(antrenör);
        }

        // POST: Antrenör/Edit/5
        // Aşırı gönderim saldırılarından korunmak için, bağlamak istediğiniz belirli özellikleri etkinleştirin, 
        // daha fazla bilgi için bkz. https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Antrenör_id,Antrenör_Bilgisi")] Antrenör antrenör)
        {
            if (ModelState.IsValid)
            {
                db.Entry(antrenör).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Antrenör_id = new SelectList(db.SporDali, "sporDali_id", "spor_secimi", antrenör.Antrenör_id);
            return View(antrenör);
        }

        // GET: Antrenör/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Antrenör antrenör = db.Antrenör.Find(id);
            if (antrenör == null)
            {
                return HttpNotFound();
            }
            return View(antrenör);
        }

        // POST: Antrenör/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Antrenör antrenör = db.Antrenör.Find(id);
            db.Antrenör.Remove(antrenör);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
