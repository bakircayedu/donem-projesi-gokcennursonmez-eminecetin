﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SalonKayitSistemi;

namespace SalonKayitSistemi.Controllers
{
    public class CalismaSeklisController : Controller
    {
        private SalonKayit1Entities db = new SalonKayit1Entities();

        // GET: CalismaSeklis
        public ActionResult Index()
        {
            var calismaSekli = db.CalismaSekli.Include(c => c.Musteri);
            return View(calismaSekli.ToList());
        }

        // GET: CalismaSeklis/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CalismaSekli calismaSekli = db.CalismaSekli.Find(id);
            if (calismaSekli == null)
            {
                return HttpNotFound();
            }
            return View(calismaSekli);
        }

        // GET: CalismaSeklis/Create
        public ActionResult Create()
        {
            ViewBag.Calisma_id = new SelectList(db.Musteri, "musteri_id", "Adi");
            return View();
        }

        // POST: CalismaSeklis/Create
        // Aşırı gönderim saldırılarından korunmak için, bağlamak istediğiniz belirli özellikleri etkinleştirin, 
        // daha fazla bilgi için bkz. https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Calisma_id,calisma_sekil")] CalismaSekli calismaSekli)
        {
            if (ModelState.IsValid)
            {
                db.CalismaSekli.Add(calismaSekli);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Calisma_id = new SelectList(db.Musteri, "musteri_id", "Adi", calismaSekli.Calisma_id);
            return View(calismaSekli);
        }

        // GET: CalismaSeklis/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CalismaSekli calismaSekli = db.CalismaSekli.Find(id);
            if (calismaSekli == null)
            {
                return HttpNotFound();
            }
            ViewBag.Calisma_id = new SelectList(db.Musteri, "musteri_id", "Adi", calismaSekli.Calisma_id);
            return View(calismaSekli);
        }

        // POST: CalismaSeklis/Edit/5
        // Aşırı gönderim saldırılarından korunmak için, bağlamak istediğiniz belirli özellikleri etkinleştirin, 
        // daha fazla bilgi için bkz. https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Calisma_id,calisma_sekil")] CalismaSekli calismaSekli)
        {
            if (ModelState.IsValid)
            {
                db.Entry(calismaSekli).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Calisma_id = new SelectList(db.Musteri, "musteri_id", "Adi", calismaSekli.Calisma_id);
            return View(calismaSekli);
        }

        // GET: CalismaSeklis/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CalismaSekli calismaSekli = db.CalismaSekli.Find(id);
            if (calismaSekli == null)
            {
                return HttpNotFound();
            }
            return View(calismaSekli);
        }

        // POST: CalismaSeklis/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            CalismaSekli calismaSekli = db.CalismaSekli.Find(id);
            db.CalismaSekli.Remove(calismaSekli);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
