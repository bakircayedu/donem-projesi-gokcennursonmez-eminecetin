﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SalonKayitSistemi;

namespace SalonKayitSistemi.Controllers
{
    public class EkHizmetsController : Controller
    {
        private SalonKayit1Entities db = new SalonKayit1Entities();

        // GET: EkHizmets
        public ActionResult Index()
        {
            var ekHizmet = db.EkHizmet.Include(e => e.Musteri);
            return View(ekHizmet.ToList());
        }

        // GET: EkHizmets/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EkHizmet ekHizmet = db.EkHizmet.Find(id);
            if (ekHizmet == null)
            {
                return HttpNotFound();
            }
            return View(ekHizmet);
        }

        // GET: EkHizmets/Create
        public ActionResult Create()
        {
            ViewBag.hizmet_id = new SelectList(db.Musteri, "musteri_id", "Adi");
            return View();
        }

        // POST: EkHizmets/Create
        // Aşırı gönderim saldırılarından korunmak için, bağlamak istediğiniz belirli özellikleri etkinleştirin, 
        // daha fazla bilgi için bkz. https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "hizmet_id,hizmet_bilgisi")] EkHizmet ekHizmet)
        {
            if (ModelState.IsValid)
            {
                db.EkHizmet.Add(ekHizmet);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.hizmet_id = new SelectList(db.Musteri, "musteri_id", "Adi", ekHizmet.hizmet_id);
            return View(ekHizmet);
        }

        // GET: EkHizmets/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EkHizmet ekHizmet = db.EkHizmet.Find(id);
            if (ekHizmet == null)
            {
                return HttpNotFound();
            }
            ViewBag.hizmet_id = new SelectList(db.Musteri, "musteri_id", "Adi", ekHizmet.hizmet_id);
            return View(ekHizmet);
        }

        // POST: EkHizmets/Edit/5
        // Aşırı gönderim saldırılarından korunmak için, bağlamak istediğiniz belirli özellikleri etkinleştirin, 
        // daha fazla bilgi için bkz. https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "hizmet_id,hizmet_bilgisi")] EkHizmet ekHizmet)
        {
            if (ModelState.IsValid)
            {
                db.Entry(ekHizmet).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.hizmet_id = new SelectList(db.Musteri, "musteri_id", "Adi", ekHizmet.hizmet_id);
            return View(ekHizmet);
        }

        // GET: EkHizmets/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EkHizmet ekHizmet = db.EkHizmet.Find(id);
            if (ekHizmet == null)
            {
                return HttpNotFound();
            }
            return View(ekHizmet);
        }

        // POST: EkHizmets/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            EkHizmet ekHizmet = db.EkHizmet.Find(id);
            db.EkHizmet.Remove(ekHizmet);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
