﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SalonKayitSistemi;

namespace SalonKayitSistemi.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Hakkimizda()
        {
           
            return View();
        }

        public ActionResult Kayitol()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Kayitol(FormCollection form)
        {
            SalonKayit1Entities db = new SalonKayit1Entities();
            Musteri musteri = new Musteri();
            Antrenör antrenor = new Antrenör();
            CalismaSekli calisma = new CalismaSekli();
            SporDali sporDali = new SporDali();
            EkHizmet ekHizmet = new EkHizmet();
            musteri.Adi = form["Adi"];
            musteri.Boy = Convert.ToInt32(form["Boy"].ToString());
            musteri.Cinsiyet = form["Cinsiyet"];
            musteri.Kilo = Convert.ToByte(form["Kilo"].ToString());
            musteri.Soyadi = form["SoyAdi"];
            musteri.TCKimlikNo = form["TCKimlikNo"];
            musteri.TelNo = form["TelNo"];
            musteri.Yas = Convert.ToByte(form["Yas"].ToString());
            musteri.Email = form["Email"];
            antrenor.Antrenör_Bilgisi = form["antrenor"];
            calisma.calisma_sekil = form["calismasekli"];
            sporDali.spor_secimi = form["spor_cesiti"];
            ekHizmet.hizmet_bilgisi = form["hizmet"];
            db.Antrenör.Add(antrenor);
            db.CalismaSekli.Add(calisma);
            db.EkHizmet.Add(ekHizmet);
            db.Musteri.Add(musteri);
            db.SporDali.Add(sporDali);
            db.SaveChanges();
            return View();
        }
       

   
    }
}