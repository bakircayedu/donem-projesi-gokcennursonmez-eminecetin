﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SalonKayitSistemi;

namespace SalonKayitSistemi.Controllers
{
    public class MusterisController : Controller
    {
        private SalonKayit1Entities db = new SalonKayit1Entities();

        // GET: Musteris
        public ActionResult Index()
        {
            var musteri = db.Musteri.Include(m => m.CalismaSekli).Include(m => m.EkHizmet).Include(m => m.SporDali);
            return View(musteri.ToList());
        }

        // GET: Musteris/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Musteri musteri = db.Musteri.Find(id);
            if (musteri == null)
            {
                return HttpNotFound();
            }
            return View(musteri);
        }

        // GET: Musteris/Create
        public ActionResult Create()
        {
            ViewBag.musteri_id = new SelectList(db.CalismaSekli, "Calisma_id", "calisma_sekil");
            ViewBag.musteri_id = new SelectList(db.EkHizmet, "hizmet_id", "hizmet_bilgisi");
            ViewBag.musteri_id = new SelectList(db.SporDali, "sporDali_id", "spor_secimi");
            return View();
        }

        // POST: Musteris/Create
        // Aşırı gönderim saldırılarından korunmak için, bağlamak istediğiniz belirli özellikleri etkinleştirin, 
        // daha fazla bilgi için bkz. https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "musteri_id,Adi,Soyadi,TCKimlikNo,Cinsiyet,Kilo,Boy,Yas,Email,TelNo")] Musteri musteri)
        {
            if (ModelState.IsValid)
            {
                db.Musteri.Add(musteri);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.musteri_id = new SelectList(db.CalismaSekli, "Calisma_id", "calisma_sekil", musteri.musteri_id);
            ViewBag.musteri_id = new SelectList(db.EkHizmet, "hizmet_id", "hizmet_bilgisi", musteri.musteri_id);
            ViewBag.musteri_id = new SelectList(db.SporDali, "sporDali_id", "spor_secimi", musteri.musteri_id);
            return View(musteri);
        }

        // GET: Musteris/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Musteri musteri = db.Musteri.Find(id);
            if (musteri == null)
            {
                return HttpNotFound();
            }
            ViewBag.musteri_id = new SelectList(db.CalismaSekli, "Calisma_id", "calisma_sekil", musteri.musteri_id);
            ViewBag.musteri_id = new SelectList(db.EkHizmet, "hizmet_id", "hizmet_bilgisi", musteri.musteri_id);
            ViewBag.musteri_id = new SelectList(db.SporDali, "sporDali_id", "spor_secimi", musteri.musteri_id);
            return View(musteri);
        }

        // POST: Musteris/Edit/5
        // Aşırı gönderim saldırılarından korunmak için, bağlamak istediğiniz belirli özellikleri etkinleştirin, 
        // daha fazla bilgi için bkz. https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "musteri_id,Adi,Soyadi,TCKimlikNo,Cinsiyet,Kilo,Boy,Yas,Email,TelNo")] Musteri musteri)
        {
            if (ModelState.IsValid)
            {
                db.Entry(musteri).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.musteri_id = new SelectList(db.CalismaSekli, "Calisma_id", "calisma_sekil", musteri.musteri_id);
            ViewBag.musteri_id = new SelectList(db.EkHizmet, "hizmet_id", "hizmet_bilgisi", musteri.musteri_id);
            ViewBag.musteri_id = new SelectList(db.SporDali, "sporDali_id", "spor_secimi", musteri.musteri_id);
            return View(musteri);
        }

        // GET: Musteris/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Musteri musteri = db.Musteri.Find(id);
            if (musteri == null)
            {
                return HttpNotFound();
            }
            return View(musteri);
        }

        // POST: Musteris/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Musteri musteri = db.Musteri.Find(id);
            db.Musteri.Remove(musteri);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
