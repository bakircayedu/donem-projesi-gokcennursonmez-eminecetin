﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SalonKayitSistemi;

namespace SalonKayitSistemi.Controllers
{
    public class SporDalisController : Controller
    {
        private SalonKayit1Entities db = new SalonKayit1Entities();

        // GET: SporDalis
        public ActionResult Index()
        {
            var sporDali = db.SporDali.Include(s => s.Antrenör).Include(s => s.Musteri);
            return View(sporDali.ToList());
        }

        // GET: SporDalis/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SporDali sporDali = db.SporDali.Find(id);
            if (sporDali == null)
            {
                return HttpNotFound();
            }
            return View(sporDali);
        }

        // GET: SporDalis/Create
        public ActionResult Create()
        {
            ViewBag.sporDali_id = new SelectList(db.Antrenör, "Antrenör_id", "Antrenör_Bilgisi");
            ViewBag.sporDali_id = new SelectList(db.Musteri, "musteri_id", "Adi");
            return View();
        }

        // POST: SporDalis/Create
        // Aşırı gönderim saldırılarından korunmak için, bağlamak istediğiniz belirli özellikleri etkinleştirin, 
        // daha fazla bilgi için bkz. https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "sporDali_id,spor_secimi")] SporDali sporDali)
        {
            if (ModelState.IsValid)
            {
                db.SporDali.Add(sporDali);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.sporDali_id = new SelectList(db.Antrenör, "Antrenör_id", "Antrenör_Bilgisi", sporDali.sporDali_id);
            ViewBag.sporDali_id = new SelectList(db.Musteri, "musteri_id", "Adi", sporDali.sporDali_id);
            return View(sporDali);
        }

        // GET: SporDalis/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SporDali sporDali = db.SporDali.Find(id);
            if (sporDali == null)
            {
                return HttpNotFound();
            }
            ViewBag.sporDali_id = new SelectList(db.Antrenör, "Antrenör_id", "Antrenör_Bilgisi", sporDali.sporDali_id);
            ViewBag.sporDali_id = new SelectList(db.Musteri, "musteri_id", "Adi", sporDali.sporDali_id);
            return View(sporDali);
        }

        // POST: SporDalis/Edit/5
        // Aşırı gönderim saldırılarından korunmak için, bağlamak istediğiniz belirli özellikleri etkinleştirin, 
        // daha fazla bilgi için bkz. https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "sporDali_id,spor_secimi")] SporDali sporDali)
        {
            if (ModelState.IsValid)
            {
                db.Entry(sporDali).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.sporDali_id = new SelectList(db.Antrenör, "Antrenör_id", "Antrenör_Bilgisi", sporDali.sporDali_id);
            ViewBag.sporDali_id = new SelectList(db.Musteri, "musteri_id", "Adi", sporDali.sporDali_id);
            return View(sporDali);
        }

        // GET: SporDalis/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SporDali sporDali = db.SporDali.Find(id);
            if (sporDali == null)
            {
                return HttpNotFound();
            }
            return View(sporDali);
        }

        // POST: SporDalis/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            SporDali sporDali = db.SporDali.Find(id);
            db.SporDali.Remove(sporDali);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
